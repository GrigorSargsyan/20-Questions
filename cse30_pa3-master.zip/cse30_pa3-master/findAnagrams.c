/*
 * Filename: findAnagrams.c
 * Author: Shaoze Wang
 * Userid: cs30xqr
 * Description: The c function that takes in a string and looks afor the
 *              matching anagrams for this string.
 * Date: Feb.27.2017
 * Source of Help: Man page 
 */

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include "pa3.h"
#include "pa3Strings.h"

/*
 * Function name: findAnagrams()
 * Function prototype: int findAnagrams( struct HashTable const * table );
 * Parameters:
 *            arg1: the table of dictionary the anagrams are located.
 * Side Effects:
 *            None
 * Error Conditions:
 *            initAnagram for input word failed.
 * Return Value:
 *            0 on success, -1 on failure.
 */

int 
findAnagrams( struct HashTable const * table ){
  FILE * infile = stdin;
  char buf [BUFSIZ];
  for ( (void)fprintf( stdout, STR_USER_PROMPT ) ;
      fgets(buf, BUFSIZ, infile) != NULL; 
     (void)fprintf( stdout, STR_USER_PROMPT ) ){
    char * ptr = strchr( buf, '\n' );
    if ( ptr != 0 ){
      (*ptr) = '\0';
    }
    struct Anagram temp;
    if ( initAnagram( buf, &temp ) == -1){
      return -1;
    }
    int index = getTableIndex( temp.sortedWord, table -> size );
    struct TableEntry * currT = &(table -> entryPtr[index]);
    int i;
    int size = currT -> numAnagrams / sizeof(struct Anagram);
    int found = 0;
    for ( i = 0; i < size; i++ ){
      struct Anagram * currA = &(currT -> anagramPtr[i]);
      if ( strncmp( temp.sortedWord, currA -> sortedWord, BUFSIZ ) == 0 ){
        unsigned int j;
        int first = 0;
        for ( j = 0; j < currA -> numWords; j++ ){
          char * currW = currA -> words[j];

          if ( strncasecmp( buf, currW, BUFSIZ ) != 0 ){
            if ( first == 0 ){
              (void)fprintf( stdout, STR_FOUND_ANAGRAMS );
            }
            (void)fprintf( stdout, "%s%s", STR_SPACE_CHAR, currW );
            found = 1;
          }
        }
        if ( found == 1 ){
          (void)fprintf( stdout, "\n" );
        }
          break;
      }
    }
    if ( !found ){
      (void)fprintf( stdout, STR_NO_ANAGRAMS );
    }
    free( temp.words[0] );
    free( temp.words );
  }
  (void)fprintf( stdout, "\n" );
  return 0;
}

/*
 * Filename: initAnagram.c
 * Author: Shaoze Wang
 * Userid: cs30xqr
 * Description: The c function that takes in a pointer to an anagram and a
 *              char array and initialize the anagram using the sorted word
 *              passed in.
 * Date: Feb.23.2017
 * Source of Help: Man page
 */


/*
 * Function name: initAnagram()
 * Function prototype: int initAnagram(const char *, struct Anagram *);
 * Description: First sort and turn the source word into upper case and used
 *              the new word to initialize the sortedWord property and then
 *              initialize the other properties
 * Parameters:
 *              arg1: src, the char array to be sorted
 *              arg2: pointer to the anagram struct
 * Side Effects:
 *              None
 * Error Conditions:
 *              When the memory allocation fails
 * Return Value:
 *              0 on success; -1 on failure.
 */
#include <string.h>
#include <stdlib.h>
#define INDEX 0
#include "pa3.h"
#include "pa3Strings.h"


int 
initAnagram( char const * src, struct Anagram * anagram ){
  char sanitized[strlen(src)+1];
  unsigned int i; int n = 0;
  for ( i = 0; i < strlen(src); i++ ){
    if ( src[i] >= 'A' && src[i] <= 'Z' ){
      sanitized[n] = src[i];
      n++;
    }
    if ( src[i] >= 'a' && src[i] <= 'z' ){
      sanitized[n] = src[i];
      n++;
    }
    if ( src[i] >= '0' && src[i] <= '9' ){
      sanitized[n] = src[i];
      n++;
    }
  }
  sanitized[n] = '\0';
  /* Get the length of the src */
  n++;
  /* Copy and sort the string */
  upperCaseSortString( sanitized, n, anagram -> sortedWord );

  /* Update the size */
  anagram -> numWords = 1;

  /* Allocate memory for word array */
  anagram -> words = (char **)malloc(sizeof(char *) * anagram->numWords );

  /* Return if the allocation failed */
  if ( !( anagram -> words ) ){
    (void)fprintf( stderr, STR_ERR_MEM_EXCEEDED );  
    return -1;
  }

  /* Allocate the space for the first index's content */
  anagram -> words[ INDEX ] = (char *)malloc(
    (strlen(src)+1) * sizeof(char) );

  /* Return if the allocation failed */
  if ( !( anagram -> words[ INDEX ] ) ){
    (void)fprintf( stderr, STR_ERR_MEM_EXCEEDED );
    free( anagram -> words );
    return -1;
  }

  /* Copy over the string */
  (void)strncpy( anagram->words[ INDEX ], src, n - 1 );
  anagram -> words[ INDEX ][ n - 1 ] = '\0';
  return 0;
}

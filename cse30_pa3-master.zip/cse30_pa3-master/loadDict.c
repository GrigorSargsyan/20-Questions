/*
 * Filename: loadDict.c
 * Author: Shaoze Wang
 * Userid: cs30xqr
 * Description: The c function that loads a dict and makes every word into a
 *              new anagram if this anagram does not exist already or append
 *              it to another extant anagram.
 * Date: Feb.23.2017
 * Source of Help: Man page
 * */

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include "pa3.h"
#include "pa3Strings.h"
#define NO_SUCH_FILE 2
#define NO_PERMISSION 14
/*
 * Function name: loadDict()
 * Function prototype: int loadDict( char *, struct HashTable * );
 * Description: Loop throught the whole dict file and archive all words as
 *              anagrams.
 * Parameters:
 *              arg1: filename, the file of the dictionary
 *              arg2: table, the hashtable of all anagrams
 * Side Effects:
 *              None
 * Error Conditions:
 *              When calling fopen() without right permission or invalid
 *              filename. 
 *              When initAnagram() returns invalid initiation.
 *              When memory allocation fails.
 * Return Value:
 *              0 on success, -1 on failure.
 * */

int
loadDict( char* filename, struct HashTable * table ){
  /* Initialize the char array that takes the read from the file */
  char buf[BUFSIZ] = {0};
 
  /* Open the file */ 
  FILE * file = fopen( filename, "r" );

  /* Check the flag after opening the file for any potential errors */
  if ( file == 0 ){
    perror( filename );
    if ( errno == NO_SUCH_FILE ){//file does not exist
      (void)fprintf( stderr, STR_ERR_FILE_INVALID );
    }
    if ( errno == NO_PERMISSION ){//no permission
      (void)fprintf( stderr, STR_ERR_FILE_PERMISSION );
    }
    return -1;//return because the file could not be opened
  }

  /* 
   * The loop that keeps reading words and stops at the EOF; it reads the
   * next line into the buf while checking if the loop should continue.
   */
  while( fgets( buf, BUFSIZ, file ) ){
    
    /* Get the length of the word read in */
    int length = strlen( buf ) + 1;
    struct Anagram word;

    /* Change the ending \n nto \0 */
    char * pos = strchr( buf, '\n' );
    if ( pos != 0 ){
      (*pos) = '\0';
    } 
    
    /* 
     * Initialize the temporary Anagram and check if the initialization
     * is successful.
     */
    if ( initAnagram(buf, & word ) == -1 ){
      return -1;//return if the initialization failed
    }
    
    /*
     * Calculate the index.
     */
    int index = getTableIndex( word.sortedWord, table -> size );
    /*
     * Access the entry in HashTable corresponding to the index.
     */
    struct TableEntry * currT = &(table -> entryPtr[index]);

    /*
     * Case b where the Anag array in this entry has not been initialized
     */
    if ( currT -> anagramPtr == 0 ){
      /* Try mallocing space for it */
      currT -> anagramPtr = ( struct Anagram *)malloc(
        sizeof(struct Anagram));

      /* If malloc failed, return */
      if ( currT ->anagramPtr == 0 ){
        (void)fprintf( stderr, STR_ERR_MEM_EXCEEDED );
        free(word.words);
        free(word.words[0]);
        return -1;
      }
      /* Update the size as 1 * sizeof(Anagram) */
      currT -> numAnagrams = sizeof(struct Anagram);

      /* Copy the info of temp Anagram to the current one */
      (void)strncpy( currT -> anagramPtr -> sortedWord, 
        word . sortedWord, length);
      currT -> anagramPtr -> sortedWord[length-1] = '\0';
      currT -> anagramPtr -> numWords = 1;
      currT -> anagramPtr -> words = ( char ** ) calloc(1, sizeof(char*));
      /* If the allocation failed, return */
      if ( currT -> anagramPtr -> words == 0 ){
        free ( currT -> anagramPtr );
        (void)fprintf( stderr, STR_ERR_MEM_EXCEEDED );
        free(word.words);
        free(word.words[0]);
        return -1;
      }
      currT -> anagramPtr -> words[0] = word . words[0];
    }
    /* 
     * Case a where the Anag array has already been initialized.
     */
    else{
      int i;
      int mode = 0;
      /* Search through the list to see if a match exists */
      for ( i = 0; i * sizeof(struct Anagram) < currT->numAnagrams; i++ ){
        struct Anagram * currA = &(currT -> anagramPtr[i]);
        /* Compare the identifier string */
        if ( strncmp(word.sortedWord, currA -> sortedWord, length) == 0 ){
          /* If a match is found, simply append the word itself */
          currA -> words = (char **)realloc( currA -> words, 
            currA -> numWords + sizeof(char*) );
          /* If the allocation failed, return */
          if ( currA -> words == 0 ){
            (void)fprintf( stderr, STR_ERR_MEM_EXCEEDED );
            free(word.words);
            free(word.words[0]);
            return -1;
          }
          /* Append the word */
          currA -> words[ currA -> numWords ] = word.words[0];
          /* Update the size */
          currA -> numWords ++;
          /* Match is found, no need to do the rest */
          mode = 1;
          break;         
        }
      }
      /* No match is found */
      if (mode == 0){
        /* Append the new Anagram at the end of the anagramPtr */
        struct Anagram * ptr = (struct Anagram *)realloc( currT -> anagramPtr,
          currT -> numAnagrams + sizeof(struct Anagram) );
        if ( ptr == 0 ){
          (void)fprintf( stderr, STR_ERR_MEM_EXCEEDED );
          free(word.words);
          free(word.words[0]);
          return -1;
        }
        currT -> anagramPtr = ptr;
        
        /* Copy the corresponding info */
        struct Anagram * currA = &(currT -> 
          anagramPtr[currT->numAnagrams/sizeof(struct Anagram)]);
          currT -> numAnagrams += sizeof(struct Anagram);
        (void)strncpy( currA -> sortedWord, word . sortedWord, length );
        currA -> sortedWord[length-1] = '\0';
        currA -> numWords = 1;
        currA -> words = (char **) calloc(1,sizeof(char*));
        if ( currA -> words == 0 ){
          free( currA );
          (void)fprintf(stderr, STR_ERR_MEM_EXCEEDED);
          free(word.words);
          free(word.words[0]);
          return -1;
        }
        currA -> words[0] = word . words[0];
      }
    }
    free(word.words);
  }
  return 0;
}

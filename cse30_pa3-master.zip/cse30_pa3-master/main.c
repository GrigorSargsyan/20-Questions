/*
 * Filename: main.c
 * Author: Shaoze Wang
 * Userid: cs30xqr
 * Description: The driver of the program; will parse the command line
 *              arguments and then decide which mode the program should
 *              operate under.
 * Date: Feb.26.2017
 * Source of Help: Man page
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include "pa3.h"
#include "pa3Strings.h"

/*
 * Function name: main()
 * Function prototype: int main( int agrc, char * argv[] );
 * Descirption: Drives the program by parsing the command line arguemnts
 *              and goes into the corresponding mode.
 * Parameters:
 *              arg1: num of arguments
 *              arg2: the list of arguments
 * Side Effects:
 *              None
 * Error Conditions:
 *              Invalid command line arguments:
 *                  Hashtable size invalid
 *                  Hashtable size too large
 *                  Hashtable index invalid
 *                  Hashtable index too large
 *              Invalid flag or miising flag
 *              Extra argument flags after parsing
 *              Hashtable size not within bounds
 *              Hashtable index not valid within the table
 *              Ran out of mempry when allocating TableEntry structs
 *              loadDict() failded 
 *              findAnagrams() indicated errors
 * Return Value:
 *              EXIT_SUCCESS on success, EXIT_FAILURE on failure.
 */

int main( int argc, char * argv[] ){
  int f = 0, s = 0, i = 0, h = 0;

  int c;

  int count = 0;

  char * fName = NULL; char * tSize = NULL; char * tIndex = NULL;

  char * fileName = NULL;
  
  int tableSize = 0; int tableIndex = 0;

  while( (c = getopt( argc, argv, ARG_STR )) != -1 ){
    if ( c == CHAR_FILE_FLAG ){
      f = 1;
      count += 2;
      fName = optarg;
      continue;
    }
    if ( c == CHAR_SIZE_FLAG ){
      s = 1;
      count += 2;
      tSize = optarg;
      continue;
    }
    if ( c == CHAR_INFO_FLAG ){
      i = 1;
      count += 2;
      tIndex = optarg;
      continue;
    }
    if ( c == CHAR_HELP_FLAG ){
      h = 1;
      count ++;
      continue;
    }
    usage( stderr, USAGE_SHORT, argv[0]);
    return EXIT_FAILURE;
  }

  if ( count + 1 < argc ){
    (void)fprintf( stderr, STR_ERR_EXTRA_ARGS, argv[count+1] );
    usage( stderr, USAGE_SHORT, argv[0] );
    return EXIT_FAILURE;
  }

  if ( f == 0 ){
    fName = DEFAULT_DICT_FILENAME;
  }
  fileName = fName;
  
  if ( s == 0 ){
    tSize = NULL;
    tableSize = DEFAULT_SIZE;
  }
  else{
    char * endptr;
    tableSize = strtoul( tSize, &endptr, 0 );
    if ( errno != 0 ){
      char  buf[BUFSIZ];
      (void)snprintf( buf, BUFSIZ, STR_ERR_CONVERTING ,tSize, 10 );
      perror( buf );
      usage( stderr, USAGE_SHORT, argv[0] );
      return EXIT_FAILURE;
    }
    if ( *endptr != '\0' ){
      (void)fprintf( stderr, STR_ERR_NOTINT, tSize );
      usage( stderr, USAGE_SHORT, argv[0] );
      return EXIT_FAILURE;
    }
  }

  if ( isInBounds( MIN_SIZE, MAX_SIZE, tableSize ) == 0 ){
    (void)fprintf( stderr, STR_ERR_RANGE, STR_ERR_SIZE, MIN_SIZE,
      MAX_SIZE );
    usage( stderr, USAGE_SHORT, argv[0] );
    return EXIT_FAILURE;
  }

  if ( i != 0 ){
    char * endptr;
    tableIndex = strtol( tIndex, &endptr, 0 );
    if ( errno != 0 ){
      char buf[BUFSIZ];
      (void)snprintf( buf, BUFSIZ, STR_ERR_CONVERTING, tIndex, 10 );
      perror( buf );
      usage( stderr, USAGE_SHORT, argv[0] );
      return EXIT_FAILURE;
    }
    if ( *endptr != '\0' ){
      (void)fprintf( stderr, STR_ERR_NOTINT, tIndex );
      usage( stderr, USAGE_SHORT, argv[0] );
      return EXIT_FAILURE;
    }
  }

  if ( isInBounds( 0, tableSize - 1, tableIndex ) == 0 ){
    (void)fprintf( stderr, STR_ERR_RANGE, STR_ERR_INDEX, 0,tableSize - 1 );
    usage( stderr, USAGE_SHORT, argv[0] );
    return EXIT_FAILURE;
  }

  if ( h == 1 ){
    usage( stdout, USAGE_LONG, argv[0] );
    return EXIT_SUCCESS;
  }

  struct HashTable table;
  table.size = tableSize;
  table.entryPtr = ( struct TableEntry * ) calloc(
    tableSize, sizeof(struct TableEntry) ); 

  if ( loadDict( fileName, &table ) != 0){
    usage( stderr, USAGE_SHORT, argv[0] );
    return EXIT_FAILURE;
  }

  if ( i == 1 ){
    printStats( &table, tableIndex );
    return EXIT_SUCCESS;
  }

  if ( findAnagrams( &table ) != 0){
    usage( stderr, USAGE_SHORT, argv[0] );
    return EXIT_FAILURE;
  }
  
  unsigned int i1;
  for ( i1 = 0; i1 < table.size; i1++ ){
    struct TableEntry * currT = &(table.entryPtr[i1]);
    unsigned int j;
    if ( currT != 0 ){
      for ( j = 0; j < currT -> numAnagrams/sizeof(struct Anagram); j++ ){
        struct Anagram * currA = &( currT -> anagramPtr[j] );
        unsigned int k;
        if ( currA != 0 ){
          for ( k = 0; k < currA -> numWords; k++ ){
            free( currA -> words[k] );
          }
          free(currA);
        }
      }
    }
  }
  free(table.entryPtr);
  return EXIT_SUCCESS;
}



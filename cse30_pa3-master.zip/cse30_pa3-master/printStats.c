/*
 * Filename: printStats.c
 * Author: Shaoze Wang
 * Userid: cs30xqr
 * Description: The c function that takes a table entry and prints out the
 *              infomation of this entry.
 * Date: Feb.26.2017
 * Source of Help: Man page
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "pa3.h"
#include "pa3Strings.h"

/* 
 * Function name: printStats()
 * Function prototype: void printStats( struct HashTable const *, int );
 * Description: prints the info of then entry at given index
 * Parameters:
 *            arg1: table, the HAshTable
 *            arg2: index, the index of the entry
 * Side Effects:
 *            None
 * Error Conditions:
 *            None. Out of bounds errs are handled in main
 * Return Value:
 *            None.
 */

void
printStats( struct HashTable const * table, int index ){
  (void)fprintf( stdout, STR_STATS_FOR_INDEX, index );
  struct TableEntry * currT = &(table -> entryPtr[index]);
  int collision = currT -> numAnagrams / sizeof( struct Anagram );
  (void)fprintf( stdout, STR_COLLISIONS, collision );
  int i, wordCount = 0, max = 0, min = 0;
  for ( i = 0; i < collision; i++ ){
    struct Anagram * currA = &(currT -> anagramPtr[i]);
    wordCount += currA -> numWords;
    if ( currT -> anagramPtr[max] . numWords < currA -> numWords ){
      max = i;
    }
    if ( currT -> anagramPtr[min] . numWords > currA -> numWords ){
      min = i;
    }
  }
  (void)fprintf( stdout, STR_NUM_WORDS, wordCount );
  char * maxWord = currT -> anagramPtr[max] . words[0];
  char * minWord = currT -> anagramPtr[min] . words[0];
  int maxCount = currT -> anagramPtr[max] . numWords - 1;
  int minCount = currT -> anagramPtr[min] . numWords - 1;
  (void)fprintf( stdout, STR_MAX_ANAGRAMS, maxWord, maxCount );
  (void)fprintf( stdout, STR_MIN_ANAGRAMS, minWord, minCount );
}

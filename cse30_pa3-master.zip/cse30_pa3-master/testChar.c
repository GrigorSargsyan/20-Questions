#include <stdio.h>

int charCompare( void const * p1, void const * p2 );

int main(){
  char lhs = 'a';
  char rhs = 'b';
  printf( "%d\n",charCompare( &lhs, &rhs ) );
}

#include <stdio.h>
#include <stdlib.h>
#include "pa3.h"
#include "pa3Strings.h"
#include "pa3Globals.c"
#include "loadDict.c"
#include "initAnagram.c"
#include "upperCaseSortString.c"
#include "findAnagrams.c"

int main(){
  struct HashTable test;
  test.size = 10;
  test.entryPtr = (struct TableEntry * )malloc( 10 * sizeof( struct TableEntry ) );
  
  if (loadDict( "dict", &test ) == 0 ){
    printf( "in\n" );
    findAnagrams( &test );
  }

  return 0;
}

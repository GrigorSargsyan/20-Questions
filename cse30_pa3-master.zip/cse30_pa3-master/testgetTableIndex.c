#include "test.h"
#include "pa3.h"

int getTableIndex( char const * ucSorted, size_t tableSize );

void testgetTableIndex(){
  char const * str = "\0";
  TEST( getTableIndex( str, 10 ) == 1 );

  char const * str1 = "\1\010";
  TEST( getTableIndex( str1, 10 ) == 4 );

  char const * str2 = "abc";
  char const * str3 = "\141\142\143";
  TEST(getTableIndex( str2, 10 ) == getTableIndex( str3, 10 )  );

}

int main(){
  testgetTableIndex();
  
  return 0;
}

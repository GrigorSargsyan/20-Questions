/*
 * Filename: testhash.c
 * Author: Shaoze Wang
 * Userid: cs30xqr
 * Description: Unit test program to test the function hash().
 * Date: Feb.27.2017
 * Sources of Help: None
 */
#include "test.h"
#include "pa3.h"

/*
 * Unit Test for hash.s
 * 
 * int hash( const char * str );
 *
 * Hash the string passed in and returns the hash value
 *
 */

int hash( char const * str );

void testhash(){
  char const * str = "\0";
  TEST( hash( str ) == HASH_START_VAL );

  char const * str1 = "\1\010";
  TEST( hash( str1 ) == (HASH_START_VAL * HASH_PRIME + 1) * HASH_PRIME + 8 );

  char const * str2 = "abc";
  TEST( hash( str2 ) == ((HASH_START_VAL * HASH_PRIME + 97) * HASH_PRIME + 98) * HASH_PRIME + 99 );

  char const * str3 = "\141\142\143";
  TEST( hash( str2 ) == hash( str3 ) );

  char const * str4 = "CSE30";
  int should = HASH_START_VAL;
  should = should * HASH_PRIME + 'C';
  should = should * HASH_PRIME + 'S';
  should = should * HASH_PRIME + 'E';
  should = should * HASH_PRIME + '3';
  should = should * HASH_PRIME + '0';
  TEST( hash( str4 ) == should );

  char const * str5 = "";
  TEST( hash( str5 ) == HASH_START_VAL );
}

int main(){
  testhash();

  return 0;
}

#include <stdio.h>
#include "pa3.h"
#include "pa3Strings.h"
#include "pa3Globals.c"
#include "initAnagram.c"
#include "upperCaseSortString.c"

int main(){
  struct Anagram test1;
  int ret = initAnagram( "AhIjUtfGW", & test1 );
  printf("%s\n%d\n%s\n", test1.sortedWord, test1.numWords, test1.words[0]);
  return 0; 
}

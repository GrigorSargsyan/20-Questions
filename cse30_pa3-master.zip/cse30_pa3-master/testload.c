#include <stdio.h>
#include "pa3.h"
#include "pa3Strings.h"
#include "pa3Globals.c"
#include "loadDict.c"
#include "initAnagram.c"
#include "upperCaseSortString.c"
#include <stdlib.h>

int main(){
  struct HashTable test;
  test.size = 10;
  test.entryPtr = (struct TableEntry *)malloc( 10 * sizeof(struct TableEntry) );
  printf("%d\n", loadDict("dict", &test));
  int i,j,k;
  for ( i = 0; i < 10; i++ ){
    struct TableEntry * currT = &(test.entryPtr[i]);
    if (currT != 0)
    for ( j = 0; j < currT -> numAnagrams / sizeof(struct Anagram); j++ ){
      struct Anagram * currA = &(currT -> anagramPtr[j]);
      if (currA != 0)
      for ( k = 0; k < currA -> numWords; k++ ){
        printf( "%d %d %d:%s\n", i, j, k, currA -> words[k] );
      }
    }
  }
  return 0;
}

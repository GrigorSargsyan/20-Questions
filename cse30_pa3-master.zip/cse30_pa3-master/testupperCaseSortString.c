#include "test.h"
#include "pa3.h"
#include "stdio.h"
#include <string.h>

void
testupperCaseSortString(){
  char * str = "AneLOpiI";
  char  dest[100];
  upperCaseSortString( str, 8, dest );
  TEST( strncmp(dest, "AEIILNOP",8) == 0 );

  char * str1 = "AdfIEqW";
  upperCaseSortString( str1, 7, dest );
  TEST( strncmp(dest, "ADEFIQW", 7) == 0 );

  char * str2 = "KloppOirnH";
  upperCaseSortString( str2, 10, dest );
  TEST( strncmp(dest, "HIKLNOOPPR", 10) == 0 );
}

int
main(){
  testupperCaseSortString();
  return 0;
}

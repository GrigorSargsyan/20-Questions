/*
 * Filename: upperCaseSortString.s
 * Author: Shaoze Wang
 * Userid: cs30xqr
 * Description: The c function that first convert every lower case letter 
 *              in a char array to upper case and then sort them based on
 *              ASCII order.
 * Date: Feb.21.2017
 * Source of Help: Man page.
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "pa3.h"
#include "pa3Strings.h"

/*
 * Function name: upperCaseSortString()
 * Function prototype: void upperCaseSortString(char const *, int, char *)
 * Description: First convert every lower case letter in a char array to
 *              upper case and then sort the based on ASCII order.
 * Parameters: 
 *              arg1: src, the string to be sorted and turned to uppercase
 *              arg2: n, the length of the char array src
 *              arg3: dest, the char array to store the sorted string
 * Side Effects:
 *              None
 * Error Conditions:
 *              When the legnth of src is less than n passed in
 *              When the length of dest is less than n passed in
 * Return Value:
 *              None
 */

void
upperCaseSortString( char const * src, int n, char * dest ){
  (void)strncpy( dest, src, n - 1 );
  
  int i = 0;

  while( i < n - 1 ){
    if ( dest[i] >= 'a' && dest[i] <= 'z' ){
      dest[i] = toupper( dest[i] );
    }
    i++;
  }
  dest[ n-1 ] = '\0';
  qsort( dest, n - 1, sizeof(char), charCompare );
}

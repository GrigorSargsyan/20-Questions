/*
 * Filename: usage.c
 * Author: Shaoze Wang
 * Userid: cs30xqr
 * Description: The c function that prints out the usage message based on 
 *              the mode passedin.
 * Date: Feb.26.2017
 * Source of Help: Man page.
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "pa3.h"
#include "pa3Strings.h"

/*
 * Function name: usage()
 * Function prototype: void usage (FILE *, enum usageMode, const char * );
 * Description:
 *           prints out the usage message to the given stream.
 * Parameters:
 *           arg1: the stream printed to
 *           arg2: the mode of the usage
 *           arg3: the name fo the program
 * Side Effects:
 *           None
 * Error Conditions:
 *           None
 * Return Value:
 *           None
 */

void 
usage( FILE * stream, enum usageMode u, const char * progName ){
  if ( u == USAGE_SHORT ){
    (void)fprintf( stream, STR_USAGE_SHORT, progName, progName );
  }
  else{
    (void)fprintf( stream, STR_USAGE_LONG, progName, MIN_SIZE, MAX_SIZE ) ;
  }
}
